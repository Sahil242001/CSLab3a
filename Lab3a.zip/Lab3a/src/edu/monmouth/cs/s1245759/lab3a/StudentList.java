package edu.monmouth.cs.s1245759.lab3a;
import java.util.ArrayList;

public class StudentList {

		//Student [] cs176Students;
		ArrayList<Student>cs176Students;
		
		/**
		 * Constructor for StudentList Class 
		 */
		StudentList () {
			cs176Students = new ArrayList<Student>(); //
			                                           
		}
		/**
		 * @param s - new student object
		 */

		public void addStudent (Student s)
		{
			cs176Students.add(s);
		}
		public Student Find (String id) 
		{
			Student foundStudent = null;
			for (Student s: cs176Students)
			{
				if( s.getStudentID() == id)
				{
					return s;
				}
			}
			return foundStudent;
		}

		public int studentCount (String major)
		{
			int count = 0;
			for (Student s : cs176Students) 
			{
				if (s.getMajor() == major)
				{
					count++; 	
				}

			}
			return count;
		}

		public Student getStudentInfo (String email)
		{
			for (Student s : cs176Students)
			{
				if ( s.getEmail() == email)
				{

					return s;
				}
			}
			return null;

		}


		public Student FindStudentByKey (String key, String value) 
		{
			Student foundStudent = null;
			for (Student s : cs176Students)
				switch (key)
				{
				case "ID": 
					if (s.getID() == value)
					{
						return s;
					}
					break;	
				case "email":
					if (s.getEmail() == value)
					{
						return s;
					}
					break;
				}
			return foundStudent;
		}



		public boolean updateGraduationYear (String id, Integer year) {
			boolean result = false;
			Student student = Find (id);
			if (student != null) {
				student.setGraduationYear(year);
				return true;
			}
			return result;
		}

		/**
		 * List the students using for-each loop
		 */

		public void listStudents()
		{
			for (Student s: cs176Students) {
				System.out.println(s.toString());
			}
		}
		

}
